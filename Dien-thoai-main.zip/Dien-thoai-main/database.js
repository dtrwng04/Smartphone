import pg from 'pg';
import env from 'dotenv';

env.config();

const { Pool } = pg;

const pool = new Pool({
  connectionString: process.env.POSTGRES_URL + "?sslmode=require",
});

pool.connect((err) => {
    if (err) throw err;
    console.log("Connect to PostgreSQL successfully!");
});

// Xuất khẩu pool như một export mặc định
export default pool;
