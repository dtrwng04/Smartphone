import { checkPRODUCT, checkHEART } from './smartphone.js';
import sinon from 'sinon';
import { expect } from 'chai';
import db from './database.js'; 

describe('checkPRODUCT', () => {
  let dbQueryStub;
  let checkHEARTStub;

  beforeEach(() => {
    dbQueryStub = sinon.stub(db, 'query');

    checkHEARTStub = sinon.stub(checkHEART);
    checkHEARTStub.withArgs(1, 123).resolves(true);
    checkHEARTStub.withArgs(2, 123).resolves(false);
  });

  afterEach(() => {
    sinon.restore();
  });

  it('should return products within a price range and matching a name search', async () => {
    const mockRows = [
      { productid: 1, image: 'image1.jpg', brand: 'Brand1', name: 'Product1', price: 100000 },
      { productid: 2, image: 'image2.jpg', brand: 'Brand2', name: 'Product2', price: 200000 },
    ];

    dbQueryStub.resolves({ rows: mockRows });

    const result = await checkPRODUCT(50000, 250000, null, null, null, 'Product', 123);

    expect(result).to.be.an('array');
    expect(result[0]).to.deep.equal([1, 2]);
    expect(result[1]).to.deep.equal(['image1.jpg', 'image2.jpg']);
    expect(result[2]).to.deep.equal(['Product1', 'Product2']);
    expect(result[3]).to.deep.equal(['₫100,000', '₫200,000']);
    expect(result[4]).to.deep.equal(['Brand1', 'Brand2']);
    expect(result[5]).to.deep.equal([true, false]);
  });
});

    