# Official
Một dự án nhỏ từ các thành viên nhóm 16 học phần Kiểm thử phần mềm HaUI <3
Lần đầu tiên làm việc remote này là một trải nghiệm đáng quý và cũng là cơ hội để các thành viên học tập, trao đổi, trau dồi kiến thức.
Một vài thông tin chi tiết:

# Hướng dẫn chạy:
1. Cài đặt Node Package Manager:
   -Mở terminal, gõ "npm i"
2. Tạo file .env thuộc thư mục smartphone
3. Dán đoạn code vào file .env: (Do google client id nên không commit lên được)
4. Chạy terminal, gõ "node test.js"
  
# Nhóm tác giả:
1. Nguyễn Thị Thanh Tình
2. Đỗ Xuân Trường
3. Nguyễn Trung Hiếu
4. Nguyễn Quốc Việt
